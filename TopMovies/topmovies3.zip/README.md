# FaceTab
Opens new tab in chrome which shows user facebook photos and most popular movies.